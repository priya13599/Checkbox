package com.nucleus.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.User;
import com.nucleus.service.IUserService;

@Controller
public class SecurityController {
	
	@Autowired
		IUserService userService;
	
	@RequestMapping("/loginform")
	public String request1()
	{
		return "loginform";
		
	}
	@RequestMapping("/loginfailure")
	public String request2(ModelMap map)
	{
		map.addAttribute("error","Invalid Credentials Input");
		return "loginform";
	}
	
	
	/*
	@RequestMapping("/defaultpage")
	public ModelAndView request5(User user)
	{
          List<String> noofroles = userService.checknoofroles(user.getUserId());
          ModelAndView model = new ModelAndView();
          model.addObject("noofroles",noofroles);
          model.setViewName("loginrole");
          return model;
	}*/
	@RequestMapping("/defaultpage")
	public String request5(HttpServletRequest request)
	{
		String target="result";
		if(request.isUserInRole("ROLE_USER"))
			target="makerfunctions";
		else if(request.isUserInRole("ROLE_ADMIN"))
			target="adminfunctions";
		return target;

	}
	@RequestMapping("/logout")
	public String request7(HttpServletRequest request)
	{
		
		return "loginform";

	}
	@RequestMapping("/notaccess")
	public String request3()
	{
		return "accessdenied";
	}
	
	
	/*@RequestMapping("/defaultpage")
	public String request5(HttpServletRequest request)
	{
		String target="result";
		if(request.isUserInRole("ROLE_USER"))
			target="makerfunctions";
		else if(request.isUserInRole("ROLE_ADMIN"))
			target="adminfunctions";
		return target;
	}*/
}