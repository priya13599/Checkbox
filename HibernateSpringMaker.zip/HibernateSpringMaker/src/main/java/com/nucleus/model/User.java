package com.nucleus.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="user90990")
public class User implements Serializable {
	@Id
	
	private String userId;
	
	private String password;
	@ManyToMany
	@JoinTable(name="authorities90990",joinColumns=@JoinColumn(name="userid"),inverseJoinColumns=@JoinColumn(name="roleid"))
	private List<Role> roles;
private int check_enable;
	
	public int getCheck_enable() {
	return check_enable;
}
public void setCheck_enable(int check_enable) {
	this.check_enable = check_enable;
}
	public List<Role> getRole() {
		return roles;
	}
	public void setRole(List<Role> roles) {
		this.roles = roles;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}