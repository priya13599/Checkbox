package com.nucleus.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.model.Role;
import com.nucleus.model.User;
@Repository
public class UserDaoImpl implements IUserDao{
	@Autowired
	SessionFactory sessionfactory;
	
	
	@Override
	public void SaveUser(User user) {
		Session session = sessionfactory.getCurrentSession();
		session.persist(user);
	}

	
	@Override
	public int retrieveRoleId(String rolename) {
		Query q = (Query) sessionfactory.getCurrentSession().createQuery("select roleId from Role where roleName=?");
		q.setParameter(0, rolename);
		System.out.println(q.list());
		List<Integer> list = q.list();
		return list.get(0);
		
	}


	
	@Override
	public void addrole(Role role) {
		Session session = sessionfactory.getCurrentSession();
		session.persist(role);
	}


	@Override
	public int checkuserid(String userid) {
Query q = (Query) sessionfactory.getCurrentSession().createQuery("select userId from User");
		
		System.out.println(q.list());
		List<String> list = q.list();
		for(int i=0;i<list.size();i++)
		{
			if(list.get(i).equals(userid))
			{
				return 0;
			}
		}
		return 1;
	}


	@Override
	public int checkroleid(int roleid) {
Query q = (Query) sessionfactory.getCurrentSession().createQuery("select roleId from Role");
		
		System.out.println(q.list());
		List<Integer> list = q.list();
		for(int i=0;i<list.size();i++)
		{
			if(list.get(i)==roleid)
			{
				return 0;
			}
		}
		return 1;
	}


	@Override
	public List<String> checknoofroles(String userid) {
    Query q = (Query) sessionfactory.getCurrentSession().createSQLQuery("select a.userid,r.rolename from authorities90990 a inner join role90990 r on r.roleid = a.roleid where a.userid in (select u.userid from authorities90990 a,user90990 u where u.userid=a.userid and u.userid=?)");
		q.setParameter(0, userid);
		System.out.println(q.list());
		List<String> list = q.list();
		
		return list;
	}

}