package com.nucleus.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nucleus.model.Customer;
import com.nucleus.model.Role;
import com.nucleus.model.User;
@Repository
public class CustomerDaoImpl implements ICustomerDao{
	@Autowired
	SessionFactory sessionfactory;
	
	
	@Override
	public void saveCustomer(Customer customer) {
		Session session = sessionfactory.getCurrentSession();
		session.persist(customer);
		
	}


	@Override
	public int deleteCustomer(Customer customer) {
		Session session = sessionfactory.getCurrentSession();
		Customer customer1 = (Customer)session.get(Customer.class, customer.getCustomerCode());
		if(customer1!=null)
		{
			session.delete(customer1);
			return 0;
		}
		else
		{System.out.println("Not Found");
			return 1;
			
		}
	}


	@Override
	public Customer displayCustomer(Customer customer) {
		Session session = sessionfactory.getCurrentSession();
		Customer customer1 = (Customer)session.get(Customer.class, customer.getCustomerCode());
		return customer1;
	}


	@Override
	public List<Customer> displayCustomer1() {
		Session session = sessionfactory.getCurrentSession();
		List<Customer> customer = session.createQuery("from Customer").list();
		return customer;
	}


	@Override
	public Customer updateCustomer(Customer customer) {
		Session session = sessionfactory.getCurrentSession();
		Customer customer1 = (Customer)session.get(Customer.class, customer.getCustomerCode());
		//System.out.println(customer1.getCustomerCode());
		return customer1;
	}


	@Override
	public void updateCustomerdetails(Customer customer) {
		Session session = sessionfactory.getCurrentSession();
		session.update(customer);
		
	}


	@Override
	public List<Customer> displayascendingorder() {
		Session session = sessionfactory.getCurrentSession();
		List<Customer> customer = session.createQuery("from Customer order by customerCode asc").list();
		return customer;
	}


	@Override
	public List<Customer> displaydescendingorder() {
		Session session = sessionfactory.getCurrentSession();
		List<Customer> customer = session.createQuery("from Customer order by customerCode desc").list();
		return customer;
	}


	@Override
	public void SaveUser(User user) {
		Session session = sessionfactory.getCurrentSession();
		session.persist(user);
		
	}


	@Override
	public int checkprimaryKey(String customercode) {
Query q = (Query) sessionfactory.getCurrentSession().createQuery("select customerCode from Customer");
		
		System.out.println(q.list());
		List<String> list = q.list();
		for(int i=0;i<list.size();i++)
		{
		if(list.get(i).equals(customercode))
		{
			return 0;
		}
		}
		return 1;
	}


	
	
	
	
	
	
	
}