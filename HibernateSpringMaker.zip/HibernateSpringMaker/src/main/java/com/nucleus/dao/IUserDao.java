package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Role;
import com.nucleus.model.User;

public interface IUserDao {
	

	public void SaveUser(User user);
	public int retrieveRoleId(String rolename);
	public void addrole(Role role);
	public int checkuserid(String userid);
	public int checkroleid(int roleid);
	public List<String> checknoofroles(String userid);
}