package com.nucleus.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.IUserDao;
import com.nucleus.model.Role;
import com.nucleus.model.User;
import com.nucleus.util.EncoderPwd;
@Service
@Transactional
public class UserServiceImpl implements IUserService{
	@Autowired
	IUserDao userDao;
	@Autowired
	EncoderPwd encoderpwd;

	@Override
	public void SaveUser1(User user, String[] role) {
		ArrayList<Role> rolelist = new ArrayList<Role>();
		for(int i=0;i<role.length;i++)
		{
			if(role[i].equals("ROLE_MAKER"))
					{
				        Role role1 = new Role();
				        role1.setRoleName(role[i]);
				        role1.setRoleId(userDao.retrieveRoleId(role[i]));
				        rolelist.add(role1);
					}
			if(role[i].equals("ROLE_USER"))
			{
		        Role role1 = new Role();
		        role1.setRoleName(role[i]);
		        role1.setRoleId(userDao.retrieveRoleId(role[i]));
		        rolelist.add(role1);
			}
			
			if(role[i].equals("ROLE_CHECKER"))
			{
		        Role role1 = new Role();
		        role1.setRoleName(role[i]);
		        role1.setRoleId(userDao.retrieveRoleId(role[i]));
		        rolelist.add(role1);
			}
			if(role[i].equals("ROLE_ADMIN"))
			{
		        Role role1 = new Role();
		        role1.setRoleName(role[i]);
		        role1.setRoleId(userDao.retrieveRoleId(role[i]));
		        rolelist.add(role1);
			}
		}
		
		
		user.setRole(rolelist);
		user.setCheck_enable(1);
		user.setPassword(encoderpwd.encodepwd(user.getPassword()));
		userDao.SaveUser(user);
	}

	@Override
	public void addrole(Role role) {
		userDao.addrole(role);
		
	}

	@Override
	public int checkuserid(String userid) {
		int i=userDao.checkuserid(userid);
	      return i;
	}

	@Override
	public int checkroleid(int roleid) {
		int i=userDao.checkroleid(roleid);
	      return i;
	}

	@Override
	public List<String> checknoofroles(String userid) {
		List<String> list = userDao.checknoofroles(userid);
		return list;
	}

}