package com.nucleus.service;

import java.util.List;

import com.nucleus.model.Customer;
import com.nucleus.model.Role;
import com.nucleus.model.User;

public interface ICustomerService {
	
	public void saveCustomer(Customer customer);
	public int deleteCustomer(Customer customer);
	public Customer displayCustomer(Customer customer);
	public List<Customer> displayCustomer1();
	public Customer updateCustomer(Customer customer);
	public void updateCustomerdetails(Customer customer2);
	public List<Customer> displayascendingorder();
	public List<Customer> displaydescendingorder();
	public void SaveUser(User user);
	public int checkprimaryKey(String customercode);

}