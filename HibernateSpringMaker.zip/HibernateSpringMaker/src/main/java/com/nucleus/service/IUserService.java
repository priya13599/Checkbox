package com.nucleus.service;

import java.util.List;

import com.nucleus.model.Role;
import com.nucleus.model.User;

public interface IUserService {
	
	
	public void SaveUser1(User user, String[] value);
public void addrole(Role role);
public int checkuserid(String userid);
public int checkroleid(int roleid);
public List<String> checknoofroles(String userid);
}